import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class SendMails {
	public static void main(String...args) {
		boolean error = false;
        if (args.length >= 5) {
			String host = args[0];
			//System.out.println(host);
			String senderMail = args[1];
			//System.out.println(senderMail);
			String senderPassword = args[2];
			//System.out.println(senderPassword);
            String title = args[3];
            String content = args[4];
			//System.out.println(title);
			//System.out.println(content);
			MailUtil sendmail = new MailUtil();
			sendmail.setHost(host);
			sendmail.setSender(senderMail);		
			sendmail.setPassword(senderPassword);			
			int length = args.length;
			if (length >= 6)
			{
				String[] receiver = new String[length - 5];
				for (int i = 5; i < length; i++)
				{
					receiver[i - 5] = args[i];
					//System.out.println((i - 5) + ":" + receiver[i - 5]);
				}
				sendmail.setReceiver(receiver);
				try
				{
					sendmail.send(title,content);	
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			} else {
				error = true;				
			}
        } else {
			error = true;			
		}
		if (error)
		{
			System.out.println("Please Usage:");
			System.out.println("java -cp /cron/lib/*:. SendMails <SMTP HOST> <Sender's Mail> <\"Sender's Mail's Password\"> <\"EMail Title\"> <\"EMail Body\"> <Receiver's Mails...>\r\n");
			System.out.println("For Example:");
			System.out.println("java -cp /cron/lib/*:. SendMails smtp.qq.com 83058327@qq.com 123456 testmail testbody arden.emily@gmail.com");
		}
	}
}
