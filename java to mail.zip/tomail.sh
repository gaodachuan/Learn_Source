#!/bin/bash


export LANG=en_US.UTF-8



HOST="smtp.163.com"
SENDER="monitor@163.com"
PASSWORD="xxxxxxxx"



RECEIVER="youremail@yourdomain.com"



#报警内容
        SUBJECT="request timeout,Please check"
        CONTENT="this eamil from monitor server"
		
#发送邮件
       /usr/local/jdk1.7.0_75/bin/java -cp /var/scripts/monitor:/var/scripts/lib/* SendMails $HOST $SENDER $PASSWORD "$SUBJECT" "$CONTENT" $RECEIVER


